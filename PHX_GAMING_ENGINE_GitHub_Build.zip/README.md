# PHX GAMING ENGINE — 0.1.1

Projeto Android nativo inicial para Android 8+ (target Android 15 / API 35).

## Implementado nesta versão
- Interface nativa PHX.
- Perfis Normal/Forte/Extremo com preferência reversível de taxa de atualização de 60/90 Hz.
- Detecção de root por `su -c id`.
- Consulta dos modos de jogo via `cmd game list-modes`.
- Leitura de resolução e densidade atuais.
- Explicações sobre os limites reais de toque e estabilidade de mira.
- Permissão e painel flutuante básico; arraste pelo título e botão de fechar.
- Restauração das preferências de taxa de atualização definidas pelo app.
- GitHub Actions para compilar e publicar o APK como Artifact.

## Limites desta versão
- Não altera governadores, voltagens, frequências mínimas/máximas, thermal throttling ou arquivos privados dos jogos.
- Não injeta comandos, não automatiza mira e não promete FPS que o jogo ou hardware não suportam.
- Resolution Lab é somente leitura nesta versão.
- A taxa de amostragem do toque é definida pelo driver/firmware; não existe API Android universal para forçá-la.
- Os perfis são básicos: alteram apenas a preferência de atualização da tela. Não são overclock e não garantem aumento de FPS.

## Compilar pelo GitHub sem PC
1. Envie os arquivos e pastas deste ZIP para a raiz do repositório, mantendo `.github/workflows/build.yml`.
2. Abra **Actions** e execute **Build PHX APK**.
3. Quando terminar com sucesso, abra a execução e baixe o Artifact **PHX-GAMING-ENGINE-debug**.
4. Extraia o Artifact e instale `app-debug.apk`.

Teste primeiro o perfil Normal. Conceda a permissão de sobreposição somente se quiser usar o painel flutuante. Use **Restaurar taxa de atualização padrão** para remover as preferências criadas pelo PHX.
