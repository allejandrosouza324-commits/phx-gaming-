# PHX GAMING ENGINE — 0.1.0

Projeto Android nativo inicial para Android 8+ (target Android 15 / API 35).

## O que está implementado
- Interface nativa PHX.
- Perfis Normal/Forte/Extremo com preferência de taxa de atualização de 60/90 Hz, reversível.
- Detecção de root por `su -c id`.
- Consulta dos modos de jogo via `cmd game list-modes`.
- Leitura de resolução/densidade atual.
- Explicações de limites reais de toque e estabilidade de mira.
- Permissão e painel flutuante básico, arrastável.
- Ação para remover as preferências de taxa de atualização definidas pelo app.

## Limites intencionais
- Não altera governadores, voltagens, frequências mínimas/máximas, thermal throttling ou arquivos privados dos jogos.
- Não injeta comandos, não automatiza mira e não promete FPS que o jogo/hardware não suporta.
- A aba de resolução é somente leitura nesta versão; alterar `wm size` sem validação pode deixar a interface inutilizável.
- A taxa de amostragem do toque é definida pelo driver/firmware e não há API Android universal para forçá-la.

## Compilar APK
Abra a pasta no Android Studio (Hedgehog ou mais recente), instale Android SDK Platform 35 e use:
`Build > Build Bundle(s) / APK(s) > Build APK(s)`

Ou:
`gradle assembleDebug`

O APK ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Instalação e uso
1. Instale o APK debug gerado pelo Android Studio.
2. Abra e conceda sobreposição apenas se quiser o painel flutuante.
3. Se tiver root, aprove o pedido do `su` quando selecionar um perfil.
4. Teste primeiro Normal. A preferência de 90 Hz só funciona se o painel do aparelho/firmware suportar.
5. Use "Restaurar taxa de atualização padrão" para remover as preferências criadas pelo PHX.

## Próxima etapa
Testar no SM-A146M, coletar saída de `cmd game list-modes`, `wm size`, `wm density` e confirmar quais nós de toque/tela existem no kernel antes de habilitar ajustes adicionais.


## Compilar automaticamente sem PC (GitHub Actions)
1. Crie um repositório GitHub vazio chamado `PHX-GAMING-ENGINE`.
2. Envie o conteúdo desta pasta (não o arquivo ZIP) para a branch `main`.
3. Abra a aba Actions e selecione `Build PHX APK`.
4. Aguarde o workflow terminar com sucesso.
5. Abra a execução concluída, baixe `PHX-GAMING-ENGINE-debug` em Artifacts e extraia o APK.
