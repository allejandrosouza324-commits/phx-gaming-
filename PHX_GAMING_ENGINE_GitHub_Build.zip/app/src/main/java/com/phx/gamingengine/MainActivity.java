package com.phx.gamingengine;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    String profile = "Normal";
    TextView status;
    int bg = Color.rgb(12,20,30), panel = Color.rgb(24,38,53), cyan = Color.rgb(70,210,255);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        build();
    }
    TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(4,8,4,8); return t;
    }
    void build() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(20,24,20,24); root.setBackgroundColor(bg);
        scroll.addView(root); setContentView(scroll);
        root.addView(text("PHX  /  GAMING ENGINE", 24, cyan));
        root.addView(text("ANDROID PERFORMANCE CONTROL  •  v0.1.0", 11, Color.LTGRAY));
        status = text("Verificando ambiente...", 14, Color.WHITE); card(status);
        addHeader("PERFORMANCE PROFILES");
        LinearLayout row = new LinearLayout(this);
        for (String p : new String[]{"Normal","Forte","Extremo"}) {
            Button btn = new Button(this); btn.setText(p); row.addView(btn,new LinearLayout.LayoutParams(0,-2,1));
            btn.setOnClickListener(v -> applyProfile(p));
        }
        root.addView(row);
        addHeader("GAME TOOLS");
        addButton("FPS / modo de jogo", v -> gameInfo());
        addButton("Resolution Lab", v -> resolutionInfo());
        addButton("Touch Engine", v -> touchInfo());
        addButton("Aim Stability", v -> aimInfo());
        addButton("Painel flutuante", v -> floating());
        addHeader("ROOT & SAFETY");
        addButton("Verificar root", v -> checkRoot());
        addButton("Restaurar taxa de atualização padrão", v -> restoreRefresh());
        addButton("Permissão de sobreposição", v -> overlayPermission());
        root.addView(text("PHX não injeta comandos no Free Fire/Minecraft, não automatiza mira e não promete FPS acima do limite físico. Ajustes de toque e resolução dependem do firmware; opções não suportadas ficam desativadas.",12,Color.LTGRAY));
        checkRoot();
    }
    void card(View v) { LinearLayout box=new LinearLayout(this); box.setPadding(12,10,12,10); box.setBackgroundColor(panel); box.addView(v); root.addView(box); }
    void addHeader(String s) { root.addView(text(s,15,cyan)); }
    void addButton(String s, View.OnClickListener l) { Button b=new Button(this); b.setText(s); b.setOnClickListener(l); root.addView(b); }
    void say(String s) { status.setText(s); }
    void applyProfile(String p) {
        profile=p;
        // Safe, reversible Android display refresh preference only. No CPU voltage/governor writes.
        String value = p.equals("Normal") ? "60.0" : "90.0";
        boolean ok = shell("settings put system peak_refresh_rate " + value);
        shell("settings put system min_refresh_rate 60.0");
        say("Perfil "+p+" selecionado. Preferência de tela: até "+value+" Hz. Aplicação: "+(ok?"solicitada":"sem root/sem permissão")+"; o firmware pode limitar.");
    }
    boolean shell(String command) {
        try {
            Process proc = Runtime.getRuntime().exec(new String[]{"su","-c",command});
            int code=proc.waitFor(); return code==0;
        } catch(Exception e) { return false; }
    }
    String read(String command) {
        try {
            Process p=Runtime.getRuntime().exec(new String[]{"sh","-c",command});
            BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder s=new StringBuilder(); String line;
            while((line=r.readLine())!=null) s.append(line).append("\n");
            p.waitFor(); return s.toString().trim();
        } catch(Exception e) { return ""; }
    }
    void checkRoot() {
        String out=read("su -c id");
        boolean yes=out.contains("uid=0");
        say("Root: "+(yes?"detectado":"não detectado")+"\n"+(yes?out:"O app funciona em modo limitado sem root."));
    }
    void gameInfo() {
        String out=read("cmd game list-modes com.dts.freefireth; cmd game list-modes com.mojang.minecraftpe");
        new AlertDialog.Builder(this).setTitle("FPS / Game Mode").setMessage(out.isEmpty()?"Não foi possível consultar os modos.":"Modos reportados pelo Android:\n"+out+"\n\nO limite real depende do jogo, tela e firmware.").setPositiveButton("OK",null).show();
    }
    void resolutionInfo() {
        String out=read("wm size; wm density");
        new AlertDialog.Builder(this).setTitle("Resolution Lab").setMessage("Configuração atual:\n"+(out.isEmpty()?"indisponível":out)+"\n\nA seleção de resoluções personalizadas ainda está em modo de leitura para evitar tela cortada ou interface inutilizável.").setPositiveButton("OK",null).show();
    }
    void touchInfo() {
        new AlertDialog.Builder(this).setTitle("Touch Engine").setMessage("Android não oferece uma configuração universal e segura para aumentar a taxa de amostragem do toque por aplicativo. O PHX não altera arquivos do sistema às cegas. Mantenha a taxa de atualização alta e desative economia de energia durante jogos.").setPositiveButton("OK",null).show();
    }
    void aimInfo() {
        new AlertDialog.Builder(this).setTitle("Aim Stability").setMessage("Ferramentas permitidas: ajuste de sensibilidade dentro do jogo, HUD e taxa de quadros estável. O PHX não move a mira, não lê a tela e não injeta comandos no jogo.").setPositiveButton("OK",null).show();
    }
    void floating() {
        if (!Settings.canDrawOverlays(this)) { overlayPermission(); return; }
        startService(new Intent(this,FloatingPanelService.class));
        say("Painel flutuante iniciado.");
    }
    void overlayPermission() {
        Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
        startActivity(i);
    }
    void restoreRefresh() {
        boolean a=shell("settings delete system peak_refresh_rate");
        boolean b=shell("settings delete system min_refresh_rate");
        say("Restauração solicitada: "+((a||b)?"preferências removidas":"não foi possível; verifique root/permissões")+". Reinicie se necessário.");
    }
}
