package com.phx.gamingengine;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.*;
import android.widget.*;
import android.graphics.Color;

public class FloatingPanelService extends Service {
    WindowManager wm; View panel;
    @Override public IBinder onBind(Intent i){ return null; }
    @Override public void onCreate(){
        super.onCreate();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(12,8,12,8);
        box.setBackgroundColor(0xEE142638);
        TextView title=new TextView(this); title.setText("PHX  •  GAME"); title.setTextColor(0xFF46D2FF); title.setTextSize(13); box.addView(title);
        Button close=new Button(this); close.setText("Fechar painel"); close.setOnClickListener(v->stopSelf()); box.addView(close);
        TextView note=new TextView(this); note.setText("Painel rápido. Ajustes completos no app."); note.setTextColor(Color.WHITE); box.addView(note);
        panel=box;
        int type=android.os.Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.END; lp.x=20; lp.y=120;
        box.setOnTouchListener(new View.OnTouchListener(){
            float x,y; int sx,sy;
            public boolean onTouch(View v, android.view.MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){x=e.getRawX();y=e.getRawY();sx=lp.x;sy=lp.y;return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){lp.x=sx+(int)(x-e.getRawX());lp.y=sy+(int)(e.getRawY()-y);wm.updateViewLayout(panel,lp);return true;}
                return false;
            }});
        wm.addView(panel,lp);
    }
    @Override public void onDestroy(){ if(panel!=null) wm.removeView(panel); super.onDestroy(); }
}
